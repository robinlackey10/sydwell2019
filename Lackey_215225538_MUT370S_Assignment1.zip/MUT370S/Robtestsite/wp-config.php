<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'Rob_db');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'uQ0 @7MQxYbjqEHT3!P3$WDhb%g9-0HGm,b2o*U*f 9`)VBVg6$f);)Px@du`e=h');
define('SECURE_AUTH_KEY',  'lkp[Zds+.Gj B:wsapv},eSJSjo2LfBWg]n+a!a$*,RBDl*PgI-eKT+pimcrG>de');
define('LOGGED_IN_KEY',    '8|H5t$0K]O%G$OAhf`KkcZ/HUurD;;S!,graiJk:+kw6tT}wVPsu;1Aq&jEgu{4M');
define('NONCE_KEY',        'd=l4B_Zo+u+Z^v8SG|QXb/f*=.n{jPNWH!vS)]ze+(y!&Ivi{eMoxP 4k=qX9gI^');
define('AUTH_SALT',        '(rx>HQmjETHGT!/J}aN07*}ga@ZUM]GJXf;YYa?D0y!r!T3//OV*WN8)*c?Dz0L{');
define('SECURE_AUTH_SALT', '#<18_<~@Ulv}8xT`/Ds(TG8rg<hM{)1c85g0g?Zd$-Sadcy*h%Dw{T -x%R`r9!C');
define('LOGGED_IN_SALT',   'VEEoHy8BEgg8F(_TB%&R(sQC,5it}W}lHY`7[*;eSpPuPp8U8~Sic 63dQ=h&YS7');
define('NONCE_SALT',       '|B[peaQ@ mnDeM[yqUe: efo4V|e=BBC8pl#yQkrZ*|jH5<bQb)j[sMLJK8;LH;E');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
